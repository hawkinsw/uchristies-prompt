#include <iostream>

#include <gradable.h>


int main() { return 0; }
